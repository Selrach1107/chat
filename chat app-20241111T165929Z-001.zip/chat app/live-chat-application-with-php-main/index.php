<?php
    header("location: login.php?redirect_link=index.php");
?>

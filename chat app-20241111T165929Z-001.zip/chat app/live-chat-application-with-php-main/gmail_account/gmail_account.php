<?php
    $email_gmail = getenv('GMAIL_EMAIL');
    $password_gmail = getenv('GMAIL_PASSWORD');
?>